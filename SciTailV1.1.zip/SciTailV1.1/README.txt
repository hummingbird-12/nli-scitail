Refer to the original SNLI dataset for their JSONL format. 

